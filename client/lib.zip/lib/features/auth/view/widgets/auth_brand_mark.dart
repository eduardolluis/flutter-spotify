import 'package:melodix/core/theme/app_pallete.dart';
import 'package:flutter/material.dart';

class AuthBrandMark extends StatelessWidget {
  const AuthBrandMark({super.key});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        ClipRRect(
          borderRadius: BorderRadius.circular(10),
          child: Image.asset('assets/images/melodix_logo.png', width: 34, height: 34),
        ),
        const SizedBox(width: 10),
        const Text(
          'Melodix',
          style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700, color: Pallete.whiteColor),
        ),
      ],
    );
  }
}
