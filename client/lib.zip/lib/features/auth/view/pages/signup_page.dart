import 'package:melodix/core/theme/app_pallete.dart';
import 'package:melodix/core/utils.dart';
import 'package:melodix/core/widgets/custom_field.dart';
import 'package:melodix/core/widgets/loader.dart';
import 'package:melodix/features/auth/view/pages/login_page.dart';
import 'package:melodix/features/auth/view/widgets/auth_brand_mark.dart';
import 'package:melodix/features/auth/view/widgets/auth_gradient_button.dart';
import 'package:melodix/features/auth/viewmodel/auth_viewmodel.dart';
import 'package:melodix/features/home/view/pages/home_page.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:melodix/core/theme/app_pallete.dart';

class SignupPage extends ConsumerStatefulWidget {
  const SignupPage({super.key});

  @override
  ConsumerState<SignupPage> createState() => _SignupPageState();
}

class _SignupPageState extends ConsumerState<SignupPage> {
  final _nameController = TextEditingController();
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();
  final formKey = GlobalKey<FormState>();

  @override
  void dispose() {
    _nameController.dispose();
    _emailController.dispose();
    _passwordController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final isLoading = ref.watch(authViewModelProvider.select((val) => val.isLoading)) == true;

    ref.listen(authViewModelProvider, (_, next) {
      next.when(
        data: (data) {
          if (data != null) {
            Navigator.pushAndRemoveUntil(
              context,
              MaterialPageRoute(builder: (context) => const HomePage()),
              (_) => false,
            );
          }
        },
        error: ((error, stackTrace) {
          showSnackBar(context, error.toString());
        }),
        loading: () {},
      );
    });

    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: AppBar(backgroundColor: Colors.transparent, elevation: 0),
      body: Container(
        decoration: const BoxDecoration(
          image: DecorationImage(
            image: AssetImage('assets/images/welcome-background.jpeg'),
            fit: BoxFit.cover,
          ),
        ),
        child: isLoading
            ? const Loader()
            : Center(
                child: SingleChildScrollView(
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 28, vertical: 40),
                    child: Form(
                      key: formKey,
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const AuthBrandMark(),
                          const SizedBox(height: 28),
                          Container(
                            padding: const EdgeInsets.fromLTRB(20, 24, 20, 24),
                            decoration: BoxDecoration(
                              color: const Color.fromRGBO(12, 18, 28, 0.68),
                              borderRadius: BorderRadius.circular(24),
                              border: Border.all(color: Pallete.gradient2.withValues(alpha: 0.18)),
                            ),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                const Text(
                                  "Sign up",
                                  style: TextStyle(
                                    fontSize: 30,
                                    fontWeight: FontWeight.w800,
                                    color: Pallete.whiteColor,
                                  ),
                                ),
                                const SizedBox(height: 6),
                                Text(
                                  "Create your account and start listening without limits.",
                                  style: TextStyle(
                                    fontSize: 14,
                                    color: Pallete.subtitleText,
                                    fontWeight: FontWeight.w400,
                                  ),
                                ),
                                const SizedBox(height: 28),

                                CustomField(hintText: "Name", controller: _nameController),
                                const SizedBox(height: 16),

                                CustomField(hintText: "Email", controller: _emailController),
                                const SizedBox(height: 16),

                                CustomField(
                                  hintText: "Password",
                                  controller: _passwordController,
                                  isObscureText: true,
                                ),
                                const SizedBox(height: 24),

                                AuthGradientButton(
                                  label: "Continue",
                                  onTap: () async {
                                    if (formKey.currentState!.validate()) {
                                      await ref
                                          .read(authViewModelProvider.notifier)
                                          .signUpUser(
                                            name: _nameController.text,
                                            email: _emailController.text,
                                            password: _passwordController.text,
                                          );
                                    } else {
                                      showSnackBar(context, "Missing fields!");
                                    }
                                  },
                                ),
                              ],
                            ),
                          ),
                          const SizedBox(height: 24),

                          Row(
                            children: [
                              Expanded(child: Divider(color: Colors.white.withValues(alpha: 0.24))),
                              Padding(
                                padding: const EdgeInsets.symmetric(horizontal: 14),
                                child: Text(
                                  "or",
                                  style: TextStyle(color: Colors.white.withValues(alpha: 0.6)),
                                ),
                              ),
                              Expanded(child: Divider(color: Colors.white.withValues(alpha: 0.24))),
                            ],
                          ),
                          const SizedBox(height: 20),

                          SizedBox(
                            width: double.infinity,
                            child: OutlinedButton.icon(
                              style: OutlinedButton.styleFrom(
                                foregroundColor: Colors.white,
                                side: BorderSide(color: Colors.white.withValues(alpha: 0.24)),
                                padding: const EdgeInsets.symmetric(vertical: 14),
                                shape: const StadiumBorder(),
                              ),
                              onPressed: () {
                                ref.read(authViewModelProvider.notifier).loginWithGoogle();
                              },
                              icon: SvgPicture.asset(
                                'assets/images/google-logo.svg',
                                height: 22,
                                width: 22,
                              ),
                              label: const Text(
                                "Continue with Google",
                                style: TextStyle(fontSize: 15, fontWeight: FontWeight.w600),
                              ),
                            ),
                          ),
                          const SizedBox(height: 28),

                          Center(
                            child: GestureDetector(
                              onTap: () {
                                Navigator.pushReplacement(
                                  context,
                                  MaterialPageRoute(builder: (context) => const LoginPage()),
                                );
                              },
                              child: RichText(
                                text: TextSpan(
                                  text: "Already have an account? ",
                                  style: Theme.of(context).textTheme.titleMedium,
                                  children: const [
                                    TextSpan(
                                      text: "Log In",
                                      style: TextStyle(
                                        color: Pallete.gradient2,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
      ),
    );
  }
}
